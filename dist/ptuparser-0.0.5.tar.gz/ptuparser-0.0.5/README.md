# ptu
A library to read and parse PicoQuant PTU files into Numpy array or Pandas dataframes. It's an improved version of Read_PTU.py example code provided by PicoQuant's github repository in performance and is implemented in Object Oriented (OO) style.
